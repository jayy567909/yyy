__MODULE__ = "ᴀꜰᴋ"
__HELP__ = """
<blockquote><b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀғᴋ ⦫<b>

<blockquote><b>⎆ perintah : 
ᚗ <code>{0}afk</code> [alasan] untuk mengaktifkan afk

⎆ perintah : 
ᚗ <code>{0}unafk</code>
ᚗ menonaktifkan afk</b></blockquote>
"""

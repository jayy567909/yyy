__MODULE__ = "zombies"
__HELP__ = """
perintah : <code>{0}zombies</code> [in group]
    mengeluarkan akun terhapus dari group
"""
